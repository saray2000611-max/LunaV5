# یادداشت ساخت Luna V5.1 — هستهٔ مستقل

- Android Gradle Plugin: 8.13.0
- Gradle: 8.13
- Kotlin Gradle Plugin: 2.2.20
- Java هدف: 17
- compileSdk: 36، targetSdk: 35، minSdk: 23
- شناسه برنامه: `com.luna.ai`
- نسخه: `5.1-independent-core`، versionCode 7
- وابستگی PDF: PDFBox Android 2.0.27.0
- WebView Asset Loader: AndroidX WebKit 1.13.0
- آواتار: دو فایل GLB و نمایشگر محلی در بسته موجودند.
- هسته و مسیریابی بدون API هوش مصنوعی ابری طراحی شده‌اند.
- رابط JNI موتور زبانی محلی اضافه شده، اما مدل GGUF و کتابخانه `libluna_inference.so` هنوز در بسته نیستند؛ پاسخ‌گویی مولد آزاد فعال نیست.
- پژوهش وب قابلیت اختیاری و نیازمند اینترنت است.
- پشتیبان‌گیری خودکار داده‌های برنامه غیرفعال شده است.
- ساخت APK واقعی و تست روی گوشی در این محیط انجام نشده؛ ابزار Gradle و Android SDK نصب نیستند.
