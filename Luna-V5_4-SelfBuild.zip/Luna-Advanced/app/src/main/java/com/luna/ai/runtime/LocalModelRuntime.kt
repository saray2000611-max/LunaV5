package com.luna.ai.runtime

import android.content.Context
import java.io.File

/**
 * Optional on-device inference bridge. Luna's core never calls a cloud AI API.
 * A compatible JNI backend can be shipped as libluna_inference.so and a GGUF
 * model can be imported into filesDir/models/luna.gguf. If either is absent,
 * callers receive an explicit unavailable status and use deterministic local tools.
 */
class LocalModelRuntime(context: Context) {
    private val modelFile = File(File(context.filesDir, MODEL_DIR), MODEL_FILE)
    private var initialized = false
    private var nativeAvailable = false
    private var nativeLoadAttempted = false

    @Synchronized
    fun status(): Status {
        val modelPresent = modelFile.isFile && modelFile.length() > MIN_MODEL_BYTES
        if (!modelPresent) return Status(false, false, "مدل زبانی محلی نصب نشده است؛ هستهٔ ابزارها و دانش آفلاین فعال‌اند.")
        if (!nativeLoadAttempted) {
            nativeLoadAttempted = true
            nativeAvailable = try {
                System.loadLibrary(NATIVE_LIBRARY)
                true
            } catch (_: LinkageError) {
                false
            } catch (_: SecurityException) {
                false
            }
        }
        if (!nativeAvailable) return Status(true, false, "فایل مدل موجود است، اما موتور استنتاج محلی همراه برنامه نصب نشده است.")
        if (!initialized) {
            initialized = try {
                NativeBridge.initialize(modelFile.absolutePath)
            } catch (_: Throwable) {
                false
            }
        }
        return if (initialized) Status(true, true, "مدل زبانی محلی آمادهٔ اجراست.")
        else Status(true, false, "موتور محلی نتوانست مدل را بارگذاری کند؛ ابزارهای آفلاین همچنان فعال‌اند.")
    }

    @Synchronized
    fun generate(prompt: String): String? {
        if (!status().ready) return null
        return try {
            NativeBridge.generate(prompt.take(MAX_PROMPT_CHARS))
                ?.trim()?.takeIf { it.isNotEmpty() }?.take(MAX_OUTPUT_CHARS)
        } catch (_: Throwable) {
            null
        }
    }

    @Synchronized
    fun close() {
        if (initialized) {
            try { NativeBridge.release() } catch (_: Throwable) { }
        }
        initialized = false
    }

    data class Status(val modelPresent: Boolean, val ready: Boolean, val message: String)

    private object NativeBridge {
        external fun initialize(modelPath: String): Boolean
        external fun generate(prompt: String): String?
        external fun release()
    }

    companion object {
        const val MODEL_DIR = "models"
        const val MODEL_FILE = "luna.gguf"
        private const val NATIVE_LIBRARY = "luna_inference"
        private const val MIN_MODEL_BYTES = 1024L * 1024L
        private const val MAX_PROMPT_CHARS = 8000
        private const val MAX_OUTPUT_CHARS = 12000
    }
}
