package com.luna.ai.ai

/** Routes only to capabilities that really exist in this APK; never to phantom cloud models. */
class ModelRouter {
    enum class Route(val id: String, val offline: Boolean) {
        LOCAL_LANGUAGE("local-language", true),
        PDF_SEARCH("pdf-search", true),
        ARCHAEOLOGY_KNOWLEDGE("archaeology-knowledge", true),
        FIELD_NOTEBOOK("field-notebook", true),
        AVATAR_CONTROL("avatar-control", true),
        WEB_RESEARCH("web-research", false),
        GENERAL_LOCAL_TOOLS("general-local-tools", true)
    }

    fun route(command: String): Route {
        val c = normalize(command)
        return when {
            contains(c, "تحقیق کن", "جستجو کن", "جست وجو کن", "در اینترنت", "در گوگل", "سرچ کن") -> Route.WEB_RESEARCH
            contains(c, "ثبت یافته", "یافته ثبت", "دفترچه یافته", "فهرست یافته") -> Route.FIELD_NOTEBOOK
            contains(c, "باستان", "تخت جمشید", "پاسارگاد", "کتیبه", "کاوش") -> Route.ARCHAEOLOGY_KNOWLEDGE
            contains(c, "pdf", "پی دی اف", "داخل فایل", "طبق فایل") -> Route.PDF_SEARCH
            contains(c, "بچرخ", "چرخ", "بنشین", "بشین", "بلند شو", "پاشو", "بایست") -> Route.AVATAR_CONTROL
            else -> Route.LOCAL_LANGUAGE
        }
    }

    private fun contains(text: String, vararg phrases: String) = phrases.any { text.contains(normalize(it)) }
    private fun normalize(text: String) = text.replace('\u200c', ' ').replace(Regex("\\s+"), " ").trim().lowercase()
}
