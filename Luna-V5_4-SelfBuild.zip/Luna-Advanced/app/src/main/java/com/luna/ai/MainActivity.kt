package com.luna.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import com.luna.ai.builder.BuilderClient
import com.luna.ai.core.LunaCore
import com.luna.ai.web.WebResearch
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private lateinit var luna: LunaCore
    private lateinit var assetLoader: WebViewAssetLoader
    private val voiceRequest = 700
    private val pdfRequest = 701
    private var ttsReady = false
    private val researchExecutor = Executors.newSingleThreadExecutor()
    private val webResearch = WebResearch()
    private val handler = Handler(Looper.getMainLooper())
    private val builder by lazy { BuilderClient(this) }
    private val builderExecutor = Executors.newSingleThreadExecutor()
    private var builderPending = false
    private var recognizer: SpeechRecognizer? = null
    private var speaking = false
    private var researching = false
    private var listening = false
    private var errorStreak = 0
    private var destroyed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        luna = LunaCore(this)
        web = findViewById(R.id.lunaWeb)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        web.addJavascriptInterface(LunaBridge(), "LunaAndroid")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        tts = TextToSpeech(this, this)
        requestAudioIfNeeded()
        scheduleListen(1500)
    }

    private inner class LunaBridge {
        @JavascriptInterface fun openPdf() { runOnUiThread { openPdfPicker() } }
        @JavascriptInterface fun speak(text: String) { runOnUiThread { this@MainActivity.speak(text) } }
        @JavascriptInterface fun sendCommand(text: String) { runOnUiThread { processCommand(text) } }
    }

    private fun requestAudioIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), voiceRequest)
        }
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun scheduleListen(delayMs: Long) {
        handler.removeCallbacks(listenRunnable)
        if (!destroyed) handler.postDelayed(listenRunnable, delayMs)
    }

    private val listenRunnable = Runnable { startVoice() }

    /** Hands-free: always listens when Luna is not speaking or researching. */
    private fun startVoice() {
        if (destroyed || speaking || researching || listening) return
        if (!hasMic()) { updateStatus("برای صحبت با لونا، اجازهٔ میکروفون را بده."); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("سرویس تشخیص گفتار روی این گوشی نصب یا فعال نیست.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(recognitionListener) }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        listening = true
        try { recognizer?.startListening(intent) }
        catch (_: Exception) { listening = false; resetRecognizer(); scheduleListen(1500) }
    }

    private fun resetRecognizer() {
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        listening = false
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { if (errorStreak == 0) updateStatus("گوش می‌دهم…") }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (text.isEmpty()) { scheduleListen(300); return }
            errorStreak = 0
            processCommand(text)
        }

        override fun onError(error: Int) {
            listening = false
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    updateStatus("برای صحبت با لونا، اجازهٔ میکروفون را بده."); return
                }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> scheduleListen(300)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> { resetRecognizer(); scheduleListen(800) }
                else -> {
                    errorStreak++
                    resetRecognizer()
                    if (errorStreak == 2) updateStatus("تشخیص گفتار فارسی کار نمی‌کند. ممکن است بستهٔ فارسی آفلاین روی گوشی نصب نباشد یا موتور گفتار به اینترنت نیاز داشته باشد.")
                    scheduleListen(if (errorStreak < 3) 1500L else 6000L)
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == voiceRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) scheduleListen(500)
    }

    override fun onResume() { super.onResume(); scheduleListen(600) }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(listenRunnable)
        try { recognizer?.cancel() } catch (_: Exception) { }
        listening = false
    }

    private fun openPdfPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, pdfRequest)
    }

    @Deprecated("Deprecated API retained for Android 6 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == pdfRequest) {
            val uri: Uri = data.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                val reply = luna.importPdf(uri)
                updateStatus(reply)
                speak(reply)
            } catch (e: Exception) {
                val reply = "خطا در خواندن PDF: ${e.message ?: "فایل نامعتبر است"}"
                updateStatus(reply); speak(reply)
            }
            return
        }
    }


    // ---- Self-modification via the Luna Agent on the owner's computer (always needs spoken approval) ----
    private fun norm(s: String) = s.replace('\u200c', ' ').replace('ي', 'ی').replace('ك', 'ک').replace(Regex("\\s+"), " ").trim()

    private fun hasAny(c: String, vararg phrases: String) = phrases.any { c.contains(norm(it)) }

    private fun handleBuilderCommand(command: String): Boolean {
        val c = norm(command)
        if (builderPending) {
            if (hasAny(c, "تایید کن", "تأیید کن", "تاییدش کن", "اعمال کن", "بساز")) {
                builderPending = false
                say("تأیید شد. نسخهٔ جدید در حال ساخته شدن است؛ چند دقیقه طول می‌کشد.")
                builderRequest("POST", "/approve", null, true)
                return true
            }
            if (hasAny(c, "رد کن", "لغو کن", "نه نمی خوام", "نمی خوام")) {
                builderPending = false
                builderRequest("POST", "/reject", null, false)
                return true
            }
        }
        val isTask = hasAny(c, "خودت را تغییر بده", "خودت رو تغییر بده", "به خودت اضافه کن", "برنامه نویسی کن", "قابلیت جدید")
        val isRollback = hasAny(c, "برگرد به نسخه قبل", "نسخه قبلی")
        if (!isTask && !isRollback) return false
        if (!builder.configured) {
            say("اتصال به کامپیوتر سازنده تنظیم نشده. این برنامه باید با Luna Builder روی کامپیوتر ساخته شده باشد.")
            return true
        }
        if (isRollback) {
            say("در حال بازگشت به نسخهٔ قبلی و ساخت آن.")
            builderRequest("POST", "/rollback", null, true)
        } else {
            say("باشه، تغییر را روی کامپیوتر آماده می‌کنم؛ بعد برایت می‌خوانم و تأیید می‌گیرم.")
            builderRequest("POST", "/task", JSONObject().put("text", command), true)
        }
        return true
    }

    private fun say(text: String) = runOnUiThread { updateStatus(text); speak(text.take(1200)) }

    private fun builderRequest(method: String, path: String, body: JSONObject?, thenPoll: Boolean) {
        builderExecutor.execute {
            try {
                val r = builder.call(method, path, body)
                if (r.has("error")) { say(r.optString("error")); return@execute }
                if (thenPoll) pollBuilder() else say(r.optString("message", "انجام شد."))
            } catch (_: Exception) {
                say("اتصال به کامپیوتر سازنده برقرار نشد. مطمئن شو کامپیوتر روشن است و در همین شبکه قرار داری.")
            }
        }
    }

    private fun pollBuilder() {
        var waited = 0
        while (!destroyed && waited < 3600) {
            Thread.sleep(5000)
            waited += 5
            val s = try { builder.call("GET", "/status", null) } catch (_: Exception) { continue }
            when (s.optString("status")) {
                "proposed" -> { builderPending = true; say(s.optString("message")); return }
                "done" -> {
                    builderPending = false
                    say(s.optString("message"))
                    val apk = s.optString("apk")
                    if (apk.isNotEmpty()) runOnUiThread {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(builder.apkUrl(apk)))) } catch (_: Exception) { }
                    }
                    return
                }
                "failed" -> { builderPending = false; say(s.optString("message")); return }
                "idle" -> { builderPending = false; return }
            }
        }
    }

    /** Shared entry point for spoken and typed commands. */
    private fun processCommand(text: String) {
        val command = text.trim().take(1000)
        if (command.isEmpty()) { scheduleListen(300); return }
        if (handleBuilderCommand(command)) return
        val result = luna.handleCommand(command)
        web.evaluateJavascript("window.lunaCommand(${org.json.JSONObject.quote(command)}, ${org.json.JSONObject.quote(result.action)})", null)
        updateStatus(result.reply)
        when (result.action) {
            "pdf.open" -> { speak("فایل PDF را از صفحه انتخاب کن."); openPdfPicker() }
            "web.search" -> runWebResearch(result.payload, false)
            "web.archaeology" -> runWebResearch(result.payload, true)
            else -> speak(result.reply.take(1200))
        }
    }

    private fun runWebResearch(query: String, archaeologyMode: Boolean) {
        updateStatus("در حال جست‌وجوی وب و بررسی حداکثر چهار صفحه…")
        researching = true
        researchExecutor.execute {
            val resultText = try {
                webResearch.search(query, archaeologyMode).text
            } catch (e: Exception) {
                "جست‌وجوی وب انجام نشد: ${e.message ?: "اتصال اینترنت یا موتور جست‌وجو در دسترس نیست."}\n" +
                    "اگر اینترنت قطع است، می‌توانی بگویی «آخرین تحقیق» تا نتیجهٔ قبلی ذخیره‌شده را ببینی، یا از دانش آفلاین باستان‌شناسی استفاده کنی."
            }
            luna.saveResearchResult(resultText.take(20000))
            runOnUiThread {
                researching = false
                updateStatus(resultText)
                speak(resultText.take(1200))
            }
        }
    }

    private fun updateStatus(text: String) {
        web.evaluateJavascript("window.setLunaStatus(${org.json.JSONObject.quote(text)})", null)
    }

    private fun speak(text: String) {
        if (!::tts.isInitialized || !ttsReady) { scheduleListen(2500); return }
        speaking = true
        try { recognizer?.cancel() } catch (_: Exception) { }
        listening = false
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LUNA_RESPONSE")
    }

    private fun onSpeechFinished() = runOnUiThread { speaking = false; scheduleListen(400) }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val fa = tts.setLanguage(Locale("fa", "IR"))
            ttsReady = fa != TextToSpeech.LANG_MISSING_DATA && fa != TextToSpeech.LANG_NOT_SUPPORTED
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { onSpeechFinished() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { onSpeechFinished() }
                override fun onError(utteranceId: String?, errorCode: Int) { onSpeechFinished() }
            })
            if (!ttsReady) updateStatus("صدای فارسی در موتور گفتار گوشی نصب نیست؛ از تنظیمات Text-to-Speech زبان فارسی را نصب کن.")
        }
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        resetRecognizer()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        researchExecutor.shutdownNow()
        builderExecutor.shutdownNow()
        if (::web.isInitialized) web.destroy()
        if (::luna.isInitialized) luna.close()
        super.onDestroy()
    }
}
