package com.luna.ai.builder

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Talks to the Luna Agent on the owner's computer. Address and token are baked into assets/builder.json by the agent at build time. */
class BuilderClient(context: Context) {
    private val baseUrl: String
    private val token: String
    val configured: Boolean

    init {
        var u = ""
        var t = ""
        try {
            val txt = context.assets.open("builder.json").bufferedReader().use { it.readText() }
            val j = JSONObject(txt)
            u = j.optString("url"); t = j.optString("token")
        } catch (_: Exception) { }
        baseUrl = u.trimEnd('/'); token = t
        configured = baseUrl.isNotEmpty() && token.isNotEmpty()
    }

    fun apkUrl(path: String) = "$baseUrl$path?t=$token"

    /** Blocking call; run on a background thread. */
    fun call(method: String, path: String, body: JSONObject? = null): JSONObject {
        val c = URL(baseUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 8000
        c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
        return JSONObject(text)
    }
}
