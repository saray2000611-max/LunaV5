package com.luna.ai.ai

import android.content.Context
import com.luna.ai.documents.PdfKnowledge
import com.luna.ai.runtime.LocalModelRuntime
import java.util.Locale

/** Offline-first assistant. A local generative model is optional; deterministic tools always remain available. */
class LocalAiEngine(context: Context, private val pdf: PdfKnowledge) {
    private val model = LocalModelRuntime(context.applicationContext)

    fun answer(input: String): String {
        val q = normalize(input).trim()
        if (q.isEmpty()) return "صدایت را واضح‌تر بگو."
        val lower = q.lowercase(Locale.ROOT)

        // Use an installed on-device model first. It never sends prompts to a network service.
        model.generate("به فارسی و با صداقت پاسخ بده. اگر مطمئن نیستی بگو.\nکاربر: ${q}")?.let { return it }

        if (containsAny(lower, "وضعیت pdf", "دانش pdf", "چه فایلی", "فایل وارد شده")) {
            return if (pdf.hasDocument()) "فایل «${pdf.documentTitle()}» در حافظه محلی موجود است و جست‌وجوی متن آن بدون اینترنت انجام می‌شود."
            else "هنوز فایلی وارد نشده است. بگو «باز کردن PDF»."
        }
        if (containsAny(lower, "طبق pdf", "طبق فایل", "در فایل", "داخل pdf", "داخل پی دی اف", "جستجو", "جست و جو", "جست‌وجو", "پیدا کن در pdf")) {
            val query = q.replace(Regex("(?i)طبق\\s*(pdf|فایل)|در\\s*فایل|داخل\\s*(pdf|پی\\s*دی\\s*اف)|پیدا\\s*کن\\s*در\\s*pdf|جست[وجوآ]+"), " ").trim()
            return pdf.search(query.ifBlank { q })
        }
        return when {
            containsAny(lower, "سلام", "درود") -> "سلام، من لونا هستم. هستهٔ آفلاین، حافظهٔ محلی و ابزارهای تخصصی آماده‌اند."
            containsAny(lower, "کمک", "چه کار", "قابلیت") -> helpText()
            containsAny(lower, "وضعیت لونا", "سلامت سیستم", "وضعیت سیستم") -> diagnostics()
            containsAny(lower, "اینترنت", "آنلاین", "جستجوی وب", "جست‌وجوی وب") ->
                "جست‌وجوی وب یک قابلیت اختیاری است و فقط با اتصال اینترنت کار می‌کند. هسته، حافظه، PDF و دانش باستان‌شناسی آفلاین هستند. برای جست‌وجو بگو «دربارهٔ [موضوع] تحقیق کن»."
            else -> "من در حالت آفلاین هستم و مدل زبانی مولد هنوز نصب یا فعال نشده است. با این حال می‌توانم PDF را جست‌وجو کنم، ابزارهای باستان‌شناسی و دفترچهٔ یافته‌ها را اجرا کنم و آواتار را کنترل کنم. برای دیدن امکانات بگو «کمک»؛ برای بررسی اجزا بگو «وضعیت لونا»."
        }
    }

    fun diagnostics(): String = buildString {
        append("گزارش سلامت لونا\n")
        append("• هسته و مسیریابی داخلی: فعال\n")
        append("• حافظه محلی: قابل استفاده با اجازهٔ کاربر\n")
        append("• جست‌وجوی PDF: فعال\n")
        append("• ابزارهای باستان‌شناسی: فعال\n")
        append("• پژوهش وب: اختیاری؛ نیازمند اینترنت\n")
        append("• ").append(model.status().message).append("\n")
        append("• وابستگی به API هوش مصنوعی ابری: وجود ندارد")
    }

    fun close() = model.close()

    private fun helpText() = "در این نسخه می‌توانم PDF متنی را وارد و جست‌وجو کنم، پژوهش وب اختیاری انجام دهم، دانش و چک‌لیست‌های باستان‌شناسی ارائه کنم، یافته‌ها را محلی ثبت کنم و آواتار را کنترل کنم. مدل زبانی مولد فقط در صورت نصب موتور و مدل محلی سازگار فعال می‌شود."
    private fun containsAny(text: String, vararg phrases: String): Boolean = phrases.any { text.contains(normalize(it).lowercase(Locale.ROOT)) }
    private fun normalize(value: String): String = value.replace('\u200c', ' ').replace('\u200f', ' ').replace(Regex("\\s+"), " ")
}
