ساخت آنلاین APK لونا با GitHub Actions
=====================================

فایل workflow در مسیر زیر قرار دارد:
.github/workflows/android-apk.yml

مراحل:
1) فایل ZIP را استخراج کنید.
2) تمام محتویات داخل پوشه Luna-Advanced (نه خود پوشه) را در ریشه مخزن GitHub قرار دهید؛
   در ریشه مخزن باید settings.gradle و build.gradle و پوشه app دیده شوند.
3) تغییرات را در شاخه main یا master ثبت کنید.
4) در GitHub وارد بخش Actions شوید و workflow با نام Build Luna Android APK را اجرا کنید.
5) پس از موفقیت، artifact با نام Luna-V5.1-archaeology-debug-apk را دانلود کنید.
6) ZIP خروجی را باز کنید تا app-debug.apk را ببینید.

نکات:
- رمز عبور یا Personal Access Token را در اختیار هیچ‌کس قرار ندهید.
- این workflow به توکن سفارشی داخل سورس نیاز ندارد.
- خروجی فعلی APK از نوع debug است و امضای انتشار نهایی ندارد.
- اجرای موفق workflow هنوز به معنی آزمایش روی گوشی واقعی نیست.
- اگر ساخت شکست خورد، گزارش خطای Actions را برای اصلاح نگه دارید.
